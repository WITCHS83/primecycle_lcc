<div class="topbar" style="position:sticky;top:0;z-index:1000;padding:10px 16px;display:flex;align-items:center;justify-content:space-between;">
  <strong>Lifecycle Canvas</strong>
  <nav style="display:flex;gap:18px;">
    <a href="/dashboard.php">Meus documentos</a>
    <a href="/admin_members.php">Admin de Membros</a>
    <a href="/logout.php">Sair</a>
  </nav>
</div>
